let Sabor1 = document.querySelector("#Sabor1");
let Sabor2 = document.querySelector("#Sabor2");
let Sabor3 = document.querySelector("#Sabor3");
let Sabor4 = document.querySelector("#Sabor4");
let Refrigerante = document.querySelector("#Refrigerante");
let btCalcularPedido = document.querySelector("#btCalcularPedido");
let Resultado = document.querySelector("#Resultado");

function Calcular() {
    let text1 = (Sabor1.value)
    let text2 = (Sabor2.value)
    let text3 = (Sabor3.value)
    let text4 = (Sabor4.value)
    let num1 = Number(Refrigerante.value);
    
    let valorPizzas = (4 * 12);
    
    let valorRefrigerantes = (num1 * 7);
    
    let total = valorPizzas + valorRefrigerantes;
    
    Resultado.innerHTML = "Sabores Escolhidos:" + "<br>" + text1 + "<br>" + text2 + "<br>" + text3 + "<br>" + text4 + "<br>" + 
    "Valor dos Refrigerantes:" + valorRefrigerantes + "<br>" + 
    "Valor Total:" + total;
}

btCalcularPedido.onclick = function() {
    Calcular();
}